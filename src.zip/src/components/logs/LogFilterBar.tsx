// =====================================================
// src/components/logs/LogFilterBar.tsx
// Полоса фильтров по типу лога
// =====================================================

import type { LogEntry, LogType } from '../../types/logs';
import { getLogColor, getLogLabel } from './log-colors';

interface LogFilterBarProps {
  logs: LogEntry[];
  filterType: LogType | 'all';
  onFilterChange: (type: LogType | 'all') => void;
}

function LogFilterBar({
  logs,
  filterType,
  onFilterChange,
}: LogFilterBarProps) {
  // Собираем уникальные типы
  const uniqueTypes: LogType[] = [];
  logs.forEach(function (l) {
    if (uniqueTypes.indexOf(l.type) === -1) uniqueTypes.push(l.type);
  });

  if (uniqueTypes.length === 0) return null;

  return (
    <div style={styles.bar}>
      <button
        style={{
          ...styles.btn,
          backgroundColor:
            filterType === 'all' ? 'var(--accent)' : 'transparent',
          color:
            filterType === 'all' ? 'var(--accent-text)' : 'var(--text-secondary)',
          borderColor:
            filterType === 'all' ? 'var(--accent)' : 'var(--border)',
        }}
        onClick={function () {
          onFilterChange('all');
        }}
      >
        Все ({logs.length})
      </button>

      {uniqueTypes.map(function (t) {
        const count = logs.filter(function (l) {
          return l.type === t;
        }).length;
        const active = filterType === t;
        const color = getLogColor(t);
        return (
          <button
            key={t}
            style={{
              ...styles.btn,
              backgroundColor: active ? color : 'transparent',
              color: active ? 'var(--accent-text)' : 'var(--text-secondary)',
              borderColor: color,
            }}
            onClick={function () {
              onFilterChange(t);
            }}
          >
            {getLogLabel(t)} ({count})
          </button>
        );
      })}
    </div>
  );
}

// =====================================================
// === Стили ===
// =====================================================
const styles: Record<string, React.CSSProperties> = {
  bar: {
    display: 'flex',
    gap: 4,
    padding: '6px 8px',
    borderBottom: '1px solid var(--border)',
    flexWrap: 'wrap',
    flexShrink: 0,
    maxHeight: 70,
    overflowY: 'auto',
  },
  btn: {
    fontSize: 10,
    padding: '3px 8px',
    borderRadius: 10,
    border: '1px solid var(--border)',
    cursor: 'pointer',
    whiteSpace: 'nowrap',
    transition: 'all 0.15s',
    fontWeight: 500,
    fontFamily: 'inherit',
  },
};

export default LogFilterBar;