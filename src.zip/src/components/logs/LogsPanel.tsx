// =====================================================
// src/components/logs/LogsPanel.tsx
// Панель журнала действий
// =====================================================

import { useEffect, useRef, useState } from 'react';
import {
  X,
  Trash2,
  Download,
  Minimize2,
  Maximize2,
  Activity,
} from 'lucide-react';
import type { LogEntry, LogType } from '../../types/logs';
import LogRow from './LogRow';
import LogFilterBar from './LogFilterBar';

// =====================================================
// === Пропсы ===
// =====================================================
interface LogsPanelProps {
  visible: boolean;
  logs: LogEntry[];
  onClose: () => void;
  onClear: () => void;
  onExport: () => void;
}

// =====================================================
// === Компонент ===
// =====================================================
function LogsPanel({
  visible,
  logs,
  onClose,
  onClear,
  onExport,
}: LogsPanelProps) {
  const [minimized, setMinimized] = useState(false);
  const [filterType, setFilterType] = useState<LogType | 'all'>('all');
  const listRef = useRef<HTMLDivElement>(null);

  useEffect(
    function () {
      if (listRef.current && visible && !minimized) {
        listRef.current.scrollTop = 0;
      }
    },
    [logs, visible, minimized]
  );

  if (!visible) return null;

  const filteredLogs =
    filterType === 'all'
      ? logs
      : logs.filter(function (l) {
          return l.type === filterType;
        });

  return (
    <div style={{ ...styles.panel, ...(minimized ? styles.panelMin : {}) }}>
      <div style={styles.header}>
        <Activity size={14} color="var(--accent)" />
        <span style={styles.title}>Журнал действий</span>
        <span style={styles.counter}>{logs.length}</span>
        <div style={{ flex: 1 }} />
        <button
          style={styles.headerBtn}
          onClick={function () {
            setMinimized(!minimized);
          }}
          title={minimized ? 'Развернуть' : 'Свернуть'}
        >
          {minimized ? <Maximize2 size={13} /> : <Minimize2 size={13} />}
        </button>
        <button style={styles.headerBtn} onClick={onExport} title="Экспорт в TXT">
          <Download size={13} />
        </button>
        <button
          style={styles.headerBtn}
          onClick={onClear}
          title="Очистить журнал"
        >
          <Trash2 size={13} />
        </button>
        <button
          style={styles.headerBtn}
          onClick={onClose}
          title="Закрыть (Ctrl+L)"
        >
          <X size={13} />
        </button>
      </div>

      {!minimized && (
        <>
          <LogFilterBar
            logs={logs}
            filterType={filterType}
            onFilterChange={setFilterType}
          />

          <div ref={listRef} style={styles.list}>
            {filteredLogs.length === 0 ? (
              <div style={styles.empty}>
                {logs.length === 0
                  ? 'Журнал пуст. Действия будут появляться здесь.'
                  : 'Нет записей с этим фильтром.'}
              </div>
            ) : (
              filteredLogs.map(function (log) {
                return <LogRow key={log.id} log={log} />;
              })
            )}
          </div>
        </>
      )}
    </div>
  );
}

// =====================================================
// === Стили ===
// =====================================================
const styles: Record<string, React.CSSProperties> = {
  panel: {
    position: 'fixed',
    bottom: 32,
    right: 16,
    width: 440,
    height: 380,
    // «Консольный» вид: фон берём из bg-modal, но с пониженной прозрачностью
    backgroundColor: 'color-mix(in srgb, var(--bg-modal) 96%, transparent)',
    backdropFilter: 'blur(var(--blur))',
    WebkitBackdropFilter: 'blur(var(--blur))',
    border: '1px solid var(--border)',
    borderRadius: 'var(--radius)',
    boxShadow: 'var(--shadow-lg)',
    display: 'flex',
    flexDirection: 'column',
    zIndex: 500,
    fontFamily: 'Segoe UI, sans-serif',
    color: 'var(--text-primary)',
    overflow: 'hidden',
  },
  panelMin: {
    height: 40,
  },
  header: {
    height: 40,
    display: 'flex',
    alignItems: 'center',
    padding: '0 10px',
    gap: 8,
    backgroundColor: 'var(--overlay-medium)',
    borderBottom: '1px solid var(--border)',
    flexShrink: 0,
  },
  title: {
    fontSize: 12.5,
    fontWeight: 600,
    color: 'var(--text-primary)',
  },
  counter: {
    fontSize: 10.5,
    backgroundColor: 'var(--accent)',
    color: 'var(--accent-text)',
    padding: '1px 7px',
    borderRadius: 10,
    fontWeight: 600,
  },
  headerBtn: {
    width: 24,
    height: 24,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'transparent',
    border: 'none',
    borderRadius: 4,
    color: 'var(--text-secondary)',
    cursor: 'pointer',
    padding: 0,
  },
  list: {
    flex: 1,
    overflowY: 'auto',
    padding: '4px 0',
  },
  empty: {
    padding: '30px 20px',
    textAlign: 'center',
    fontSize: 12,
    color: 'var(--text-muted)',
    fontStyle: 'italic',
  },
};

export default LogsPanel;