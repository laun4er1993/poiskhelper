// =====================================================
// src/components/logs/LogRow.tsx
// Одна строка журнала
// =====================================================

import type { LogEntry } from '../../types/logs';
import { getLogColor, getLogLabel } from './log-colors';

interface LogRowProps {
  log: LogEntry;
}

function LogRow({ log }: LogRowProps) {
  const color = getLogColor(log.type);

  return (
    <div style={styles.entry}>
      <span style={styles.time}>{log.time}</span>
      <span
        style={{
          ...styles.badge,
          backgroundColor: 'color-mix(in srgb, ' + color + ' 15%, transparent)',
          color: color,
          borderColor: 'color-mix(in srgb, ' + color + ' 45%, transparent)',
        }}
      >
        {getLogLabel(log.type)}
      </span>
      <div style={styles.textWrap}>
        <span style={styles.message}>{log.message}</span>
        {log.details && <span style={styles.details}>{log.details}</span>}
      </div>
    </div>
  );
}

// =====================================================
// === Стили ===
// =====================================================
const styles: Record<string, React.CSSProperties> = {
  entry: {
    display: 'flex',
    alignItems: 'flex-start',
    gap: 6,
    padding: '5px 10px',
    fontSize: 11.5,
    borderBottom: '1px solid var(--border)',
    lineHeight: 1.4,
  },
  time: {
    color: 'var(--text-muted)',
    fontSize: 10.5,
    fontFamily: 'Consolas, monospace',
    flexShrink: 0,
    minWidth: 55,
    paddingTop: 1,
  },
  badge: {
    fontSize: 9.5,
    fontWeight: 700,
    padding: '1px 5px',
    borderRadius: 3,
    border: '1px solid',
    flexShrink: 0,
    letterSpacing: 0.3,
    whiteSpace: 'nowrap',
  },
  textWrap: {
    flex: 1,
    display: 'flex',
    flexDirection: 'column',
    gap: 1,
    minWidth: 0,
  },
  message: {
    color: 'var(--text-primary)',
    wordBreak: 'break-word',
  },
  details: {
    color: 'var(--text-muted)',
    fontSize: 10.5,
    fontStyle: 'italic',
  },
};

export default LogRow;