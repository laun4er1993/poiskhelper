// =====================================================
// src/components/logs/log-colors.ts
// Цвета и подписи для типов логов
// =====================================================

import type { LogType } from '../../types/logs';

/**
 * Возвращает CSS-переменную (или hex) для типа лога.
 * Использует семантические переменные темы, чтобы лог-панель
 * оставалась «консольной», но подстраивалась под светлую/тёмную тему.
 */
export function getLogColor(type: LogType): string {
  switch (type) {
    case 'add':
    case 'save':
      return 'var(--success)';
    case 'delete':
      return 'var(--danger)';
    case 'move':
    case 'load':
      return 'var(--info)';
    case 'copy':
      return 'var(--info)';
    case 'cut':
    case 'measure':
      return 'var(--warning)';
    case 'paste':
      return 'var(--accent)';
    case 'rename':
    case 'update':
      return 'var(--warning)';
    case 'import':
      return 'var(--accent)';
    case 'export':
      return 'var(--success)';
    case 'visibility':
      return 'var(--text-secondary)';
    case 'new':
      return 'var(--text-muted)';
    case 'undo':
    case 'redo':
      return 'var(--danger)';
    case 'sort':
      return 'var(--info)';
    case 'pin':
      return 'var(--warning)';
    case 'project':
      return 'var(--accent)';
    default:
      return 'var(--text-secondary)';
  }
}

/**
 * Короткая подпись типа лога для бейджа.
 */
export function getLogLabel(type: LogType): string {
  switch (type) {
    case 'add':
      return 'ДОБАВЛЕНО';
    case 'delete':
      return 'УДАЛЕНО';
    case 'move':
      return 'ПЕРЕМЕЩЕНО';
    case 'copy':
      return 'КОПИЯ';
    case 'cut':
      return 'ВЫРЕЗАНО';
    case 'paste':
      return 'ВСТАВЛЕНО';
    case 'rename':
      return 'ПЕРЕИМЕНОВАНО';
    case 'import':
      return 'ИМПОРТ';
    case 'export':
      return 'ЭКСПОРТ';
    case 'visibility':
      return 'ВИДИМОСТЬ';
    case 'update':
      return 'ИЗМЕНЕНО';
    case 'measure':
      return 'ИЗМЕРЕНИЕ';
    case 'save':
      return 'СОХРАНЕНО';
    case 'load':
      return 'ЗАГРУЖЕНО';
    case 'new':
      return 'НОВЫЙ';
    case 'undo':
      return 'ОТМЕНА';
    case 'redo':
      return 'ПОВТОР';
    case 'sort':
      return 'СОРТИРОВКА';
    case 'pin':
      return 'ЗАКРЕПЛЕНО';
    case 'project':
      return 'ПРОЕКТ';
    default:
      return String(type).toUpperCase();
  }
}